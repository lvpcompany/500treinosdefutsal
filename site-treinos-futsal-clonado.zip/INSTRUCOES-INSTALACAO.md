# Site Treinos de Futsal - Clonado

## Descrição
Este é um clone completo do site "Treinos de Futsal" baixado de https://treinosdefutsal.conteudosesportivos.com.br

## Conteúdo do Pacote
- `index.html` - Página principal do site
- `wp-content/` - Todos os recursos do WordPress (CSS, JS, imagens, plugins)
- `wp-includes/` - Arquivos essenciais do WordPress

## Como Usar

### Opção 1: Servidor Local Simples
1. Extraia o arquivo ZIP
2. Navegue até a pasta `site-clonado`
3. Execute um servidor HTTP local:
   ```bash
   # Python 3
   python3 -m http.server 8000
   
   # Python 2
   python -m SimpleHTTPServer 8000
   
   # Node.js (se tiver npx instalado)
   npx serve .
   ```
4. Acesse http://localhost:8000 no seu navegador

### Opção 2: Hospedagem Web
1. Extraia o arquivo ZIP
2. Faça upload de todos os arquivos da pasta `site-clonado` para seu servidor web
3. Configure o domínio para apontar para o arquivo `index.html`

## Recursos Incluídos
- ✅ HTML completo da página
- ✅ Todos os arquivos CSS (Elementor, WordPress, tema Kava)
- ✅ Todos os arquivos JavaScript
- ✅ Imagens e recursos visuais
- ✅ Fontes do Google (Roboto, Poppins, Roboto Slab, Baloo 2)
- ✅ Ícones Font Awesome e Elementor
- ✅ Layout responsivo (mobile/desktop)

## Funcionalidades
- Design responsivo para dispositivos móveis
- Animações CSS
- Menu interativo
- Botão WhatsApp
- Contadores animados
- Seções expansíveis (toggle)

## Observações Técnicas
- O site foi clonado usando wget com conversão de links para funcionamento offline
- Todos os recursos externos foram baixados e convertidos para caminhos relativos
- O site mantém a funcionalidade original do Elementor e WordPress
- Compatível com navegadores modernos

## Suporte
Este é um clone estático do site original. Para funcionalidades que dependem de servidor (formulários, banco de dados), será necessário implementação adicional.

---
**Data da Clonagem:** 20 de Agosto de 2025
**Site Original:** https://treinosdefutsal.conteudosesportivos.com.br

